#ifndef VARIABILE_C
#define VARIABILE_C 10
#endif

#ifndef VARIABILE_E
#define VARIABILE_E 3
#endif

#ifndef N_CASSE
#define N_CASSE 2
#endif

#ifndef TIMER_PULIZIA_CARRELLI
#define TIMER_PULIZIA_CARRELLI 20
#endif

#ifndef TIMER_BUTTAFUORI
#define TIMER_BUTTAFUORI 10
#endif

#ifndef TIMER_AGGIORNAMENTO_UI
#define TIMER_AGGIORNAMENTO_UI 1
#endif

#ifndef FILE_LOG
#define FILE_LOG "log.txt"
#endif